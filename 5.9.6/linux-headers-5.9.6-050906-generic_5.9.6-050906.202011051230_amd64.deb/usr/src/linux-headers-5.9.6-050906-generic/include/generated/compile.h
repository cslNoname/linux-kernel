/* This file is auto generated, version 202011051230 */
/* SMP */
#define UTS_MACHINE "x86_64"
#define UTS_VERSION "#202011051230 SMP Thu Nov 5 17:35:33 UTC 2020"
#define LINUX_COMPILE_BY "kernel"
#define LINUX_COMPILE_HOST "sita"
#define LINUX_COMPILER "gcc (Ubuntu 10.2.0-13ubuntu1) 10.2.0, GNU ld (GNU Binutils for Ubuntu) 2.35.1"
