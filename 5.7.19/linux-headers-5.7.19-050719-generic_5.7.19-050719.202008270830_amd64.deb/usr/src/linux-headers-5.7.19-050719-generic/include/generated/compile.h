/* This file is auto generated, version 202008270830 */
/* SMP */
#define UTS_MACHINE "x86_64"
#define UTS_VERSION "#202008270830 SMP Thu Aug 27 08:35:40 UTC 2020"
#define LINUX_COMPILE_BY "kernel"
#define LINUX_COMPILE_HOST "sita"
#define LINUX_COMPILER "gcc version 10.2.0 (Ubuntu 10.2.0-5ubuntu2), GNU ld (GNU Binutils for Ubuntu) 2.35"
