/* This file is auto generated, version 202006171132 */
/* SMP */
#define UTS_MACHINE "x86_64"
#define UTS_VERSION "#202006171132 SMP Wed Jun 17 16:31:10 UTC 2020"
#define LINUX_COMPILE_BY "kernel"
#define LINUX_COMPILE_HOST "sita"
#define LINUX_COMPILER "gcc version 9.3.0 (Ubuntu 9.3.0-13ubuntu1)"
