/* This file is auto generated, version 202004210831 */
/* SMP */
#define UTS_MACHINE "x86_64"
#define UTS_VERSION "#202004210831 SMP Tue Apr 21 08:35:25 UTC 2020"
#define LINUX_COMPILE_BY "kernel"
#define LINUX_COMPILE_HOST "kathleen"
#define LINUX_COMPILER "gcc version 9.3.0 (Ubuntu 9.3.0-10ubuntu2)"
